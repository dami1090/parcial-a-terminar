#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "libDami.h"
#define totalUsuario 5
#define totalProducto 10

int main()
{
    eUsuario usuarios[totalUsuario];
    eProducto productos[totalProducto];
    inicializarUsuarios(usuarios, totalUsuario);
    inicializarProductos(productos, totalProducto);

    char idUsuarioAux[50];
    char passwordAux[50];

    int publicar;
    int ultimaPublicacion=1;
    int i;
    int opcion;
    int lugarLibreUsuario;

    inicializarEstado(usuarios,totalUsuario,0);
    //cargarhardcore(usuarios,);


    while(opcion != 11)
    {
         opcion = ingresarInt("1 - Alta Usuario \n2 - Modif datos usuario \n3 - Baja usuario\n4 - Publicar producto\n5 - Modicficar publicacion\n6 - Cancelar Publicacion\n7 - Comprar producto\n8 - Listar publicaciones de ususario\n9 - Listar publicaciones\n10 - Listar usuarios\n11 - Salir\n\n");
         switch(opcion)
         {
            case 1:
                lugarLibreUsuario=buscarLugar(usuarios,totalUsuario);
                if(lugarLibreUsuario == -1)
                {
                    printf("\nUsuarios completos, no se puede ingresar un nuevo usuario\n\n");
                    break;
                }
                printf("\nAlta usuario\n");

                if(!ingresarRespAlfanumerica("ingrese nombre de usuario: \n\n",idUsuarioAux))
                {
                    printf ("El nombre de usuario debe ser numeros o letras\n\n");
                    break;
                }
                if(!ingresarRespAlfanumerica("ingrese password: \n",passwordAux))
                {
                    printf ("El password del usuario debe ser numeros o letras\n\n");
                    break;
                }

                strcpy(usuarios[lugarLibreUsuario].idUsuario,idUsuarioAux);
                strcpy(usuarios[lugarLibreUsuario].password,passwordAux);
                usuarios[lugarLibreUsuario].estadoUsuario=1;
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                publicar = crearPublicacion(productos,totalProducto, ultimaPublicacion, usuarios, totalUsuario);
            if(publicar!=-1)
            {
                printf("Producto publicado correctamente\n");
                ultimaPublicacion++;
            }
            else
            {
                printf("no queda espacio para una nueva publicacion");
            }
                break;
            case 5:
                break;
            case 6:
                break;
            case 7:
                break;
            case 8:
                break;
            case 9:
                break;
            case 10:
                break;

         }

    }



    return 0;
}
