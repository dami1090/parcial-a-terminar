# practicar-parcial
